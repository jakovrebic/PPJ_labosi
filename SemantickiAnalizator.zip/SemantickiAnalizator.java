import java.util.*;

public class SemantickiAnalizator {
    private static Deque<Map<String, String>> stogDijelovaKodaSVarijablama = new ArrayDeque<>();
    private static List<String> linije = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) linije.add(sc.nextLine());

        stogDijelovaKodaSVarijablama.add(new HashMap<>());

        for (int i = 0; i < linije.size(); i++) {
            String linija = linije.get(i);

            if (linija.contains("<za_petlja>")) {
                stogDijelovaKodaSVarijablama.add(new HashMap<>());

            } else if (linija.contains("KR_AZ")) {
                stogDijelovaKodaSVarijablama.removeLast();

            } else if (linija.contains("IDN")) {
                Map<String, String> varijableUTrenutnomSegmentuKoda = stogDijelovaKodaSVarijablama.peekLast();
                linija = linija.trim();
                String[] dijeloviLinije = linija.split(" ");
                String brojLinijeGdjeJeVarijablaKoristena = dijeloviLinije[1];
                String imeVarijable = dijeloviLinije[2];

                if (linije.get(i + 1).contains("OP_PRIDRUZI")) {
                    if (varijablaPostojiUOstatkuKoda(imeVarijable) == null) {
                        varijableUTrenutnomSegmentuKoda.putIfAbsent(imeVarijable, brojLinijeGdjeJeVarijablaKoristena);
                    }
                    continue;
                } else if (linije.get(i - 2).contains("<za_petlja>")) {
                    varijableUTrenutnomSegmentuKoda.put(imeVarijable, brojLinijeGdjeJeVarijablaKoristena);
                    continue;
                }

                if (!varijableUTrenutnomSegmentuKoda.containsKey(imeVarijable)) {
                    if (varijablaPostojiUOstatkuKoda(imeVarijable) != null) {
                        System.out.println(brojLinijeGdjeJeVarijablaKoristena + " " + varijablaPostojiUOstatkuKoda(imeVarijable) + " " + imeVarijable);
                    } else {
                        System.out.println("err " + brojLinijeGdjeJeVarijablaKoristena + " " + imeVarijable);
                        System.exit(0);
                    }
                } else {
                    if (brojLinijeGdjeJeVarijablaKoristena.equals(varijableUTrenutnomSegmentuKoda.get(imeVarijable))) {
                        System.out.println("err " + brojLinijeGdjeJeVarijablaKoristena + " " + imeVarijable);
                        System.exit(0);
                    }
                    String linijaGdjeJeVarijablaInstancirana = varijableUTrenutnomSegmentuKoda.get(imeVarijable);
                    System.out.println(brojLinijeGdjeJeVarijablaKoristena + " " + linijaGdjeJeVarijablaInstancirana + " " + imeVarijable);
                }
            }
        }
    }

    private static String varijablaPostojiUOstatkuKoda(String variableName) {
        for (Map<String, String> variablesInSegment : stogDijelovaKodaSVarijablama) {
            if (variablesInSegment.containsKey(variableName)) {
                return variablesInSegment.get(variableName);
            }
        }
        return null;
    }
}
