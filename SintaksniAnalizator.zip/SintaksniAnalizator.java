import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SintaksniAnalizator {

    private static short trenutnaLinija = 0;
    private static short trenutniPomakULiniji = 0;
    private static String kljucnaRijec = " ";
    private static List<String> linije = new ArrayList<>();
    private static StringBuilder izlaz = new StringBuilder();

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc;

        sc = new Scanner(System.in);

        while (sc.hasNextLine()) linije.add(sc.nextLine());
        postaviKljucnuRijec();

        ispisi("<program>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN|KR_ZA| ")) {
            lista_naredbi();
        } else {
            error();
        }

        System.out.print(izlaz.toString());
    }

    private static void lista_naredbi() {
        ispisi("<lista_naredbi>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN|KR_ZA")) {
            naredba();
            lista_naredbi();
        } else if (kljucnaRijec.matches("KR_AZ| ")) {
            ispisi("$");
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void naredba() {
        ispisi("<naredba>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN")) {
            naredba_pridruzivanja();
        } else if (kljucnaRijec.matches("KR_ZA")) {
            za_petlja();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void za_petlja() {
        ispisi("<za_petlja>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("KR_ZA")) {
            ispisiLiniju();
            ispisiLiniju();
            ispisiLiniju();
            e();
            ispisiLiniju();
            e();
            lista_naredbi();
            ispisiLiniju();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void naredba_pridruzivanja() {
        ispisi("<naredba_pridruzivanja>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN")) {
            ispisiLiniju();
            ispisiLiniju();
            e();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void e() {
        ispisi("<E>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN|BROJ|OP_MINUS|OP_PLUS|L_ZAGRADA")) {
            t();
            e_lista();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void t() {
        ispisi("<T>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN|BROJ|OP_MINUS|OP_PLUS|L_ZAGRADA")) {
            p();
            t_lista();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void p() {
        ispisi("<P>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("IDN|BROJ")) {
            ispisiLiniju();
        } else if (kljucnaRijec.matches("OP_PLUS|OP_MINUS")) {
            ispisiLiniju();
            p();
        } else if (kljucnaRijec.matches("L_ZAGRADA")) {
            ispisiLiniju();
            e();
            ispisiLiniju();
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void e_lista() {
        ispisi("<E_lista>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("OP_PLUS|OP_MINUS")) {
            ispisiLiniju();
            e();
        } else if (kljucnaRijec.matches("IDN|KR_ZA|KR_DO|KR_AZ|D_ZAGRADA| ")) {
            ispisi("$");
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void t_lista() {
        ispisi("<T_lista>");
        trenutniPomakULiniji++;
        if (kljucnaRijec.matches("OP_PUTA|OP_DIJELI")) {
            ispisiLiniju();
            t();
        } else if (kljucnaRijec.matches("IDN|KR_ZA|KR_DO|KR_AZ|OP_PLUS|OP_MINUS|D_ZAGRADA| ")) {
            ispisi("$");
        } else {
            error();
        }
        trenutniPomakULiniji--;
    }

    private static void postaviKljucnuRijec() {
        if (trenutnaLinija != linije.size()) {
            kljucnaRijec = linije.get(trenutnaLinija).split(" ")[0];
        } else {
            kljucnaRijec = " ";
        }
    }

    private static void ispisiLiniju() {
        for (int i = 0; i < trenutniPomakULiniji; i++) izlaz.append(" ");
        izlaz.append(linije.get(trenutnaLinija));
        izlaz.append("\n");
        trenutnaLinija++;
        postaviKljucnuRijec();
    }

    private static void error() {
        izlaz.setLength(0);
        izlaz.append("err ");
        if (trenutnaLinija != linije.size()) {
            izlaz.append(linije.get(trenutnaLinija));
        } else {
            izlaz.append("kraj");
        }
        izlaz.append("\n");
        System.out.print(izlaz.toString());
        System.exit(0);
    }

    private static void ispisi(String projekcija) {
        for (int i = 0; i < trenutniPomakULiniji; i++) izlaz.append(" ");
        izlaz.append(projekcija);
        izlaz.append("\n");
    }
}
