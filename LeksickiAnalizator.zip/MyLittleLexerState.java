public enum MyLittleLexerState {
    OPERATOR, TEXT, NUMBER, COMMENT, EOF, SPACE
}
