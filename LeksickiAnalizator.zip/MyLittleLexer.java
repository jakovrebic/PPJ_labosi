public class MyLittleLexer {

    private final String inputList;
    private char[] input;
    private final int lineNumber;

    private int currentIndex = 0;
    private MyLittleLexerState currentState;
    private StringBuilder currentToken;

    public MyLittleLexer(String inputList, int lineNumber) {
        super();
        this.inputList = inputList;
        this.lineNumber = lineNumber;
        input = inputList.toCharArray();
    }

    public boolean hasNextToken() {
        ignoreWhitespace();
        if(currentIndex >= input.length) {
            return false;
        }
        return true;
    }

    public Token getNextToken() {
        currentToken = new StringBuilder();

        currentState = getLexerState();
        switch(currentState) {
            case TEXT: {
                return handleTextState();
            }
            case NUMBER: {
                return handleNumberState();
            }
            case COMMENT: {
                return handleCommentState();
            }
            case OPERATOR: {
                return handleOperatorState();
            }
        }


        return null;
    }

    private Token handleTextState() {
        while(getLexerState() == MyLittleLexerState.TEXT || getLexerState() == MyLittleLexerState.NUMBER) {
            if(isWhitespace(input[currentIndex])) {
                currentIndex++;
                break;
            }
            currentToken.append(input[currentIndex]);
            currentIndex++;
        }
        String token = currentToken.toString().trim();
        if(Constants.keywords.containsKey(token)) {
            Token newtoken = Constants.keywords.get(token);
            newtoken.setLineNumber(lineNumber);
            return newtoken;
        }else {
            return new Token(token, TokenType.IDN, lineNumber);
        }
    }

    private Token handleNumberState() {
        while(getLexerState() == MyLittleLexerState.NUMBER) {
            if(isWhitespace(input[currentIndex])) {
                currentIndex++;
                break;
            }
            currentToken.append(input[currentIndex]);
            currentIndex++;
        }
        return new Token(currentToken.toString(), TokenType.BROJ, lineNumber);
    }

    private Token handleCommentState() {
        currentIndex++;
        if(currentIndex == input.length || !isComment(input[currentIndex])) {
            Token newtoken = Constants.operators.get(input[currentIndex-1]);
            newtoken.setLineNumber(lineNumber);
            return newtoken;
        }else {
            return new Token("ignore", TokenType.IGNORE);
        }
    }

    private Token handleOperatorState() {
        Token newtoken = Constants.operators.get(input[currentIndex++]);
        newtoken.setLineNumber(lineNumber);
        return newtoken;
    }

    private MyLittleLexerState getLexerState() {
        if(currentIndex >= input.length) {
            return MyLittleLexerState.EOF;
        }
        else if(isNumber(input[currentIndex])) {
            return MyLittleLexerState.NUMBER;
        }else if(isComment(input[currentIndex])) {
            return MyLittleLexerState.COMMENT;
        }else if(Constants.operators.containsKey(input[currentIndex])) {
            return MyLittleLexerState.OPERATOR;
        }else {
            return MyLittleLexerState.TEXT;
        }
    }

    private void ignoreWhitespace() {
        for(; currentIndex < input.length && isWhitespace(input[currentIndex]);
            currentIndex++);
    }

    private boolean isWhitespace(char character) {
        if(character == '\t' || character == '\n' || character == ' ') {
            return true;
        }
        return false;
    }

    private boolean isNumber(char character) {
        if(character >= '0' && character <= '9') {
            return true;
        }
        return false;
    }

    private boolean isComment(char character) {
        if(character == '/') {
            return true;
        }
        return false;
    }

}
