public class Token {

    private final String text;
    private final TokenType type;
    private int lineNumber;

    public Token(String text, TokenType type, int lineNumber) {
        this(text, type);
        this.setLineNumber(lineNumber);
    }

    public Token(String text, TokenType type) {
        super();
        this.text = text;
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public TokenType getType() {
        return type;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    @Override
    public String toString() {
        return type + " " + getLineNumber() + " " + text;
    }



}
