import java.util.HashMap;
import java.util.Map;

public class Constants {

    static final Map<Character, Token> operators = new HashMap<Character, Token>() {{
        put('=', new Token("=", TokenType.OP_PRIDRUZI));
        put('+', new Token("+", TokenType.OP_PLUS));
        put('-', new Token("-", TokenType.OP_MINUS));
        put('*', new Token("*", TokenType.OP_PUTA));
        put('/', new Token("/", TokenType.OP_DIJELI));
        put('(', new Token("(", TokenType.L_ZAGRADA));
        put(')', new Token(")", TokenType.D_ZAGRADA));
    }};

    static final Map<String, Token> keywords = new HashMap<String, Token>() {{
        put("za", new Token("za", TokenType.KR_ZA));
        put("od", new Token("od", TokenType.KR_OD));
        put("do", new Token("do", TokenType.KR_DO));
        put("az", new Token("az", TokenType.KR_AZ));
    }};

}
