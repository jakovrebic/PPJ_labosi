import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LeksickiAnalizator {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        List<String> list = new ArrayList<>();
        while(scanner.hasNext()) {
            String line = scanner.nextLine();
            if(line.length() == 0) break;
            list.add(line);
        }
        scanner.close();

        MyLittleLexer myLittleLexer;
        int lineNumber = 0;
        for(String input: list) {
            lineNumber++;
            myLittleLexer = new MyLittleLexer(input, lineNumber);
            while(myLittleLexer.hasNextToken()) {
                Token token = myLittleLexer.getNextToken();
                if(token.getType() == TokenType.IGNORE) break;
                System.out.println(token);
            }
        }
    }
}
